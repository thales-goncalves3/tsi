public class MeuAdaptador {
}
